<?php

class DDI_StoreOriginals extends KokenPlugin implements KokenOriginalStore
{
    public function send($localFile)
    {
        return false;
    }
}
