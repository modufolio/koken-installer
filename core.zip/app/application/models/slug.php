<?php

class Slug extends DataMapper
{
}
