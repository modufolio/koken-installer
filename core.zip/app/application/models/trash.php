<?php

class Trash extends DataMapper
{
    public $table = 'trash';
}

/* End of file trash.php */
/* Location: ./application/models/trash.php */
